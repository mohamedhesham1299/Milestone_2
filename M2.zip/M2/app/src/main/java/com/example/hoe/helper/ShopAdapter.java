package com.example.hoe.helper;

import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
//import com.example.hoe.Dashboard;
import com.example.hoe.Dashboard;
import com.example.hoe.MainActivity;
import com.example.hoe.R;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.tasks.Task;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class ShopAdapter extends RecyclerView.Adapter<ShopAdapter.ShopViewHolder>  {
    private static ArrayList<Double> userlocation;
    FusedLocationProviderClient fusedLocationProviderClient;
    Location currentLocation;
    private Context mCtx;
    private List<Shop_product> Shop_productList;
    private List<Shop> Shop_list;
    private Task<Location> task;




    private static final String TAG = ShopAdapter.class.getSimpleName();


//    public ShopAdapter(double a ,double b){
//        Longe=a;
//        late=b;
//
//    }

    public ShopAdapter(Context mCtx, List<Shop_product> Shop_productList, List<Shop> Shop_list , Task<Location> task ){
        this.mCtx = mCtx;
        this.Shop_productList = Shop_productList;
        this.Shop_list=Shop_list;
        this.task=task;


    }


//    public ShopAdapter(Context mCtx, List<Shop_product> Shop_productList ){
//        this.mCtx = mCtx;
//        this.Shop_productList = Shop_productList;
//        this.myshop=myshop;
//
//    }



    public ShopViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.activity_shop_products, null);
        return new ShopViewHolder(view);

    }


    public void onBindViewHolder(ShopViewHolder holder, int position) {
//        Log.d(TAG, "SHOPLIST: " + getItemCount2());
//        Log.d(TAG, "SHOPPRDUCTLIST: " + getItemCount());
   //     fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(ShopAdapter);
        Shop_product shopproduct = Shop_productList.get(position);
        Shop s1 = Shop_list.get(position);
        holder.textView_Shop_name.setText(s1.getShop_Name());
        holder.textViewSpeciall_offers.setText(shopproduct.getSpecial_Offers());
        holder.textViewPrice.setText(String.valueOf(shopproduct.getPrice())+" LE ");
        double longs=Double.parseDouble(s1.getLongitude());
        double lats=Double.parseDouble(s1.getLatitude());
         // prebare distance to function
        ///////////////////////////////////////////////
        Location user = new Location("User") ;
        user.setLatitude(task.getResult().getLatitude());
        user.setLongitude(task.getResult().getLongitude());
        Location shop = new Location("shop");
        shop.setLatitude(lats);
        shop.setLongitude(longs);
        /////////////////////////////////////////////
        int distace = (int) (user.distanceTo(shop)/1000) ;
        Log.d(TAG, "999999999999999999999999999999999999999999 " + distace);

        holder.textViewRatingShop.setText(Integer.toString(distace)+ " Km ");
        //Log.d(TAG, "onBindViewHolder: "+dist(late,Longe,lats,longs));

        Log.d(TAG, "PLACE IN MAP: " + s1.getShop_Name() +"  " + s1.getLatitude() + " " + s1.getLongitude() +" ");
        // this part for the shop image when we insert it
        try {
            URL Imageurl =  new URL(s1.getImage());
            Glide.with(mCtx)
                    .load(Imageurl)
                    .into(holder.imageView);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }



        //new Dashboard();



    }




    public int getItemCount() {
        return Shop_productList.size();
    }
    public int getItemCount2() {
        return Shop_list.size();
    }


    class ShopViewHolder extends RecyclerView.ViewHolder {

        TextView  textViewSpeciall_offers, textViewPrice,textView_Shop_name , textViewRatingShop;
        ImageView imageView;

        public ShopViewHolder(View itemView) {
            super(itemView);
            textViewRatingShop= itemView.findViewById(R.id.textViewRatingShop);
            textView_Shop_name = itemView.findViewById(R.id.textViewShop_Name);
            textViewSpeciall_offers = itemView.findViewById(R.id.textViewOfferDesc);
            textViewPrice = itemView.findViewById(R.id.textViewPrice_Shop);
            imageView = itemView.findViewById(R.id.Shop_image);
        }
    }


}