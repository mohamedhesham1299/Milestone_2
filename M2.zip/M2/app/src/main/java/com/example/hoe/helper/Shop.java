package com.example.hoe.helper;

public class Shop {
    private int Shop_ID;
    private String Shop_Name;
    private String Latitude;
    private String Longitude;
    private String image ;

    public Shop(int id, String name, String lat,String log,String imj) {
        this.Shop_ID = id;
        this.Shop_Name = name;
        this.Latitude = lat;
        this.Longitude=log;
        this.image=imj ;
    }

    public String getImage() {
        return image;
    }

    public int getShop_ID() {
        return Shop_ID;
    }

    public String getShop_Name() {
        return Shop_Name;
    }

    public String getLatitude() {
        return Latitude;
    }

    public String getLongitude() {
        return Longitude;
    }
}
