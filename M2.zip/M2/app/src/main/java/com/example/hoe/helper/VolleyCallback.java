package com.example.hoe.helper;

import java.util.List;

public interface VolleyCallback {
    void onSuccess(List<Shop> result);
}
