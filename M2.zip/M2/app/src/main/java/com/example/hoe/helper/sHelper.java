package com.example.hoe.helper;

public class sHelper {

    private String Special_Offers;
    private int price;
    private String shopname;
    private String lant;
    private String lon;
    private String image;



    public String getShopname() {
        return shopname;
    }

    public String getLant() {
        return lant;
    }

    public String getLon() {
        return lon;
    }

    public String getImage() {
        return image;
    }

    public sHelper( String Special_Offers, int price, String sname , String lat , String longa , String imj) {

        this.Special_Offers = Special_Offers;
        this.price = price ;
        this.shopname = sname ;
        this.lant = lat ;
        this.lon = longa ;
        this.image = imj ;

    }



    public String getSpecial_Offers() {
        return Special_Offers;
    }


    public double getPrice() {
        return price;
    }

}
