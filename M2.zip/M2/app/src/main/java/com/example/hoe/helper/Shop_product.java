package com.example.hoe.helper;

public class Shop_product  {

        private int Service_id;
        private int Shop_id;
        private String Special_Offers;
        private int price;


    public int getShop_id() {
        return Shop_id;
    }

    public int getService_id() {
        return Service_id;
    }

    public Shop_product(int Service_id, int Shop_id, String Special_Offers, int price) {
            this.Service_id = Service_id;
            this.Shop_id = Shop_id ;
            this.Special_Offers = Special_Offers;
            this.price = price ;


        }

        public int getId() {
            return Shop_id;
        }

        public String getSpecial_Offers() {
            return Special_Offers;
        }


        public double getPrice() {
            return price;
        }

    }

